#!/bin/bash

# SHIRO Technologies - Batch 1 Deployment Script
# Extracts and deploys first 3 components

echo "🚀 SHIRO Technologies - Batch 1 Deployment"
echo "==========================================="
echo ""
echo "This script will:"
echo "  1. Extract 3 component files to your project"
echo "  2. Build the application"
echo "  3. Push to GitHub"
echo ""

# Get the script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Navigate to project directory
echo "📍 Navigating to project..."
cd ~/projects/shiro-group-monorepo/my-turborepo/apps/shirotechnologies-com

if [ ! -f "package.json" ]; then
    echo "❌ ERROR: Not in shirotechnologies-com directory"
    echo "   Current directory: $(pwd)"
    exit 1
fi

echo "✅ Found project directory"
echo ""

# Create directory structure if needed
echo "📁 Creating directory structure..."
mkdir -p src/components/layout

# Copy the 3 component files
echo "📝 Copying component files..."

if [ -f "$SCRIPT_DIR/src/components/layout/Header.tsx" ]; then
    cp "$SCRIPT_DIR/src/components/layout/Header.tsx" src/components/layout/
    echo "  ✅ Header.tsx"
else
    echo "  ❌ Header.tsx not found in package"
fi

if [ -f "$SCRIPT_DIR/src/components/layout/Footer.tsx" ]; then
    cp "$SCRIPT_DIR/src/components/layout/Footer.tsx" src/components/layout/
    echo "  ✅ Footer.tsx"
else
    echo "  ❌ Footer.tsx not found in package"
fi

if [ -f "$SCRIPT_DIR/src/components/layout/StickyCTA.tsx" ]; then
    cp "$SCRIPT_DIR/src/components/layout/StickyCTA.tsx" src/components/layout/
    echo "  ✅ StickyCTA.tsx"
else
    echo "  ❌ StickyCTA.tsx not found in package"
fi

echo ""
echo "✅ Component files copied"
echo ""

# Verify files exist
echo "🔍 Verifying files..."
MISSING=0

for file in "src/components/layout/Header.tsx" "src/components/layout/Footer.tsx" "src/components/layout/StickyCTA.tsx"; do
    if [ -f "$file" ]; then
        echo "  ✅ $file"
    else
        echo "  ❌ $file (MISSING)"
        MISSING=$((MISSING + 1))
    fi
done

echo ""

if [ $MISSING -gt 0 ]; then
    echo "⚠️  WARNING: $MISSING files are missing!"
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Build
echo "🔨 Building application..."
npm run build

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Build failed!"
    echo ""
    echo "This is expected - you still need more components."
    echo "But the 3 files have been added to your project."
    echo ""
    read -p "Push these 3 files to GitHub anyway? (y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Push to GitHub
echo ""
echo "📤 Pushing to GitHub..."
cd ~/projects/shiro-group-monorepo

git add .
git commit -m "Add first 3 layout components (Header, Footer, StickyCTA)"
git push origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 SUCCESS! First 3 components deployed to GitHub!"
    echo ""
    echo "✅ Files added:"
    echo "   - Header.tsx"
    echo "   - Footer.tsx"
    echo "   - StickyCTA.tsx"
    echo ""
    echo "📋 Next batch will include:"
    echo "   - Logo.tsx"
    echo "   - CookieConsent.tsx"
    echo "   - Hero.tsx"
    echo ""
    echo "Ready for Batch 2? Let me know!"
else
    echo ""
    echo "❌ Git push failed. Check errors above."
fi
